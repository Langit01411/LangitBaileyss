async function fetchLatestBaileysVersion() {
  return { version: [2, 2410, 11], isLatest: true }
}

module.exports = { fetchLatestBaileysVersion }