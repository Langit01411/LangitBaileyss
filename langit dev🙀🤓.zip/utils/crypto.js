function generateKeys() {
  return { publicKey: 'PUB_KEY', privateKey: 'PRIV_KEY' }
}

module.exports = { generateKeys }
